package com.dthoperator.ui;

import java.util.Random;
import java.util.Scanner;
import com.dthoperator.exception.*;
import com.dthoperator.bean.RechargeDetails;
import com.dthoperator.service.*;

public class RechargeClient {
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)throws UserException {
		// TODO Auto-generated method stub
		int choice;
		RechargeClient ob=new RechargeClient();
		RechargeCollectionHelper ob2=new RechargeCollectionHelper();
		while(true){
			System.out.println("1-Make a Recharge");
			System.out.println("2-Display Recharge Details");
			System.out.println("3-Exit");
			
			choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
			System.out.println("Make Recharge");
			ob.inputRechargeDetails();
			break;
			case 2:
			System.out.println("Display Recharge Details");
			ob2.displayRechargeDetails();
			break;
			case 3:
			System.exit(0);
			default:
			System.out.println("Invalid choice");
			}
		}
	}
	
	public void inputRechargeDetails() throws UserException
	{
		RechargeCollectionHelper ob=new RechargeCollectionHelper();
		RechargeDataValidator ob2=new RechargeDataValidator();
		
		String dthOperator,consumerNo,rechargePlan,amount;
		int txnID;
		System.out.println("enter DTH Operator:");
		dthOperator=sc.next();
		if(!ob2.validatedthOperator(dthOperator)){
			System.exit(0);
		}
		System.out.println("Enter consumer number");
		consumerNo=sc.next();
		if(!ob2.validateConsumerNo(consumerNo)){
			System.exit(0);
		}
		System.out.println("Enter recharge plan");
		rechargePlan=sc.next();
		if(!ob2.validatePlan(rechargePlan)){
			System.exit(0);
		}
		System.out.println("Enter amount");
		amount=sc.next();
		if(!ob2.validateAmount(amount)){
			System.exit(0);
		}
		Random randomGenerator = new Random();
		int txn_id = randomGenerator.nextInt(9999);
		RechargeDetails details=new RechargeDetails(dthOperator,Integer.parseInt(consumerNo),rechargePlan,Integer.parseInt(amount),txn_id);
		ob.addRechargeDetails(details);

	}
}


