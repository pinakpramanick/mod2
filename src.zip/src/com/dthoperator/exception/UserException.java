package com.dthoperator.exception;
import java.lang.Exception;
public class UserException extends Exception {
	public UserException()
	{
		System.out.println(" Give correct input");
		return;

	}
}
