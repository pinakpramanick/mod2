package com.dthoperator.service;

import java.util.ArrayList;
import java.util.List;

import com.dthoperator.bean.RechargeDetails;

public class RechargeCollectionHelper {
	static List<RechargeDetails> list = new ArrayList<RechargeDetails>();
	
static{
		
		RechargeDetails obj1=new RechargeDetails("Airtel",10893434,"Monthly",210,4567);
		list.add(obj1);
		RechargeDetails obj2=new RechargeDetails("DishTV",30332212,"Yearly",1260,2345);
		list.add(obj2);
		RechargeDetails obj3=new RechargeDetails("Reliance",89234343,"Quarterly",650,1234);
		list.add(obj3);
	}
	
	public void addRechargeDetails(RechargeDetails obj)
	{
		list.add(obj);
	
	}  
	
	public void displayRechargeDetails()
	{
		for(Object object: list)
			System.out.println(object);
	}
}
