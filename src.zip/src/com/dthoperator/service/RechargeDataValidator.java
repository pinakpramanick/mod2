package com.dthoperator.service;

import java.util.regex.Pattern;
import com.dthoperator.exception.*;
public class RechargeDataValidator {
	
	public boolean validatedthOperator(String dthOperator) throws UserException {
		
		try {if(dthOperator.equals("Airtel")||dthOperator.equals("DishTV")||dthOperator.equals("Reliance")||dthOperator.equals("TATASky")){
		return true;
		}
		else
			throw new UserException();
		}
		catch (Exception e)
		{
			System.out.println("Enter correct DTH Operator");
			return false;
		}		
	}
	
	public boolean validateConsumerNo(String consumerNo) throws UserException {
		String pattern="(\\d){10}";
		try {if(Pattern.matches(pattern,consumerNo)){
			return true;
		}
		else
	throw new UserException();
		}
		catch (Exception e)
		{
			System.out.println("Enter correct Consumer Number");
			return false;
		}
	}
	
	public boolean validatePlan(String rechargePlan) throws UserException {
		try {if(rechargePlan.equals("Monthly")||rechargePlan.equals("Quarterly")||rechargePlan.equals("Half Yearly")||rechargePlan.equals("Annual")){
		return true;
		}
		else
	throw new UserException();
		}
		catch (Exception e)
		{
			System.out.println("Enter correct Plan");
			return false;
		}		
	}
	
	public boolean validateAmount(String amount) throws UserException {
		String pattern="(\\d){3,4}";
		try {if(Pattern.matches(pattern,amount)){
			return true;
		}
		else
	throw new UserException();
		}
		catch (Exception e)
		{
			System.out.println("Enter correct amount");
			return false;
		}
		
		
	}
}
